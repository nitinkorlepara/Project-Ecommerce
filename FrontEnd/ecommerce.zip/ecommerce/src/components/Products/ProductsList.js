import React from 'react'

function ProductsList() {
    return (
        <div>
            <h1>productlist</h1>
        </div>
    )
}

export default ProductsList
