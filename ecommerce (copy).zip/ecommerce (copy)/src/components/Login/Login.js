import React, { Component } from 'react'

export class Login extends Component {
    render() {
        return (
            <div>
                <h1>Login to add products
                </h1>
            </div>
        )
    }
}

export default Login
