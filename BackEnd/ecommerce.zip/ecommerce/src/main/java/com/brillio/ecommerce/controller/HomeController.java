package com.brillio.ecommerce.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	
}
